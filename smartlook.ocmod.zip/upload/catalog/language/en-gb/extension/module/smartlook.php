<?php
/**
 * @author Tomáš Blatný
 */

$_['heading_title'] = 'SmartLook';
